/*
# Create security_logs table for Qalqon.uz

1. New Tables
- `security_logs`
- `id` (uuid, primary key)
- `event_type` (text, not null) - e.g. 'apk_blocked', 'sandbox_redirect', 'file_approved', 'file_scanning', 'scan_started', 'scan_complete'
- `file_name` (text, nullable) - name of the file involved in the event
- `file_source` (text, nullable) - source of the file, e.g. 'Play Store', 'Side load', 'Browser download'
- `threat_level` (text, nullable) - 'safe', 'warning', 'danger'
- `details` (text, nullable) - additional human-readable description
- `android_version` (text, nullable) - simulated device Android version string
- `created_at` (timestamptz, default now())
2. Security
- Enable RLS on `security_logs`.
- Grant CRUD to `anon` + `authenticated` so the Data API can reach the table.
- Allow anon + authenticated CRUD because this is a single-tenant prototype demo with no sign-in.
3. Indexes
- Index on `created_at` desc for recent-logs queries.
- Index on `event_type` for filtering by event category.
*/

CREATE TABLE IF NOT EXISTS security_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  file_name text,
  file_source text,
  threat_level text,
  details text,
  android_version text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_security_logs_created_at ON security_logs (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_security_logs_event_type ON security_logs (event_type);

ALTER TABLE security_logs ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON security_logs TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_security_logs" ON security_logs;
CREATE POLICY "anon_select_security_logs" ON security_logs FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_security_logs" ON security_logs;
CREATE POLICY "anon_insert_security_logs" ON security_logs FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_security_logs" ON security_logs;
CREATE POLICY "anon_update_security_logs" ON security_logs FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_security_logs" ON security_logs;
CREATE POLICY "anon_delete_security_logs" ON security_logs FOR DELETE
  TO anon, authenticated USING (true);

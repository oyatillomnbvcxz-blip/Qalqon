import { supabase } from './supabase';

export async function insertLog(params: {
  event_type: string;
  file_name?: string | null;
  file_source?: string | null;
  threat_level?: string | null;
  details?: string | null;
  android_version?: string | null;
}) {
  const { error } = await supabase.from('security_logs').insert({
    event_type: params.event_type,
    file_name: params.file_name ?? null,
    file_source: params.file_source ?? null,
    threat_level: params.threat_level ?? null,
    details: params.details ?? null,
    android_version: params.android_version ?? 'Android 14 (API 34)',
  });
  if (error) console.warn('Failed to insert log:', error.message);
}

export async function fetchLogs(limit = 50) {
  const { data, error } = await supabase
    .from('security_logs')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) {
    console.warn('Failed to fetch logs:', error.message);
    return [];
  }
  return data ?? [];
}

export async function clearAllLogs() {
  const { error } = await supabase.from('security_logs').delete().neq('id', '00000000-0000-0000-0000-000000000000');
  if (error) console.warn('Failed to clear logs:', error.message);
}

export async function deleteLog(id: string) {
  const { error } = await supabase.from('security_logs').delete().eq('id', id);
  if (error) console.warn('Failed to delete log:', error.message);
}

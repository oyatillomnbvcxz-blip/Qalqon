import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type SecurityLog = {
  id: string;
  event_type: string;
  file_name: string | null;
  file_source: string | null;
  threat_level: string | null;
  details: string | null;
  android_version: string | null;
  created_at: string;
};

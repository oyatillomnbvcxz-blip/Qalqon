import { View, Text, StyleSheet } from 'react-native';
import { ShieldAlert } from 'lucide-react-native';
import { useI18n } from '@/lib/i18nContext';
import { colors, spacing, typography } from '@/lib/theme';

export default function UnsupportedScreen() {
  const { t } = useI18n();

  return (
    <View style={styles.container}>
      <View style={styles.iconWrap}>
        <ShieldAlert size={64} color={colors.error[400]} strokeWidth={2} />
      </View>
      <Text style={styles.alertText}>{t('unsupportedAlert')}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.neutral[950],
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
  },
  iconWrap: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: colors.error[900],
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.xl,
    borderWidth: 2,
    borderColor: colors.error[500],
  },
  alertText: {
    fontFamily: typography.body,
    fontSize: 18,
    lineHeight: 28,
    color: colors.neutral[100],
    textAlign: 'center',
  },
});

import { View, Text, StyleSheet, Pressable, ScrollView, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Check, Globe, Smartphone, Info, Shield, ChevronRight, Wifi } from 'lucide-react-native';
import { useI18n } from '@/lib/i18nContext';
import { languages, type Language } from '@/lib/i18n';
import { colors, spacing, radius, typography } from '@/lib/theme';

export default function SettingsScreen() {
  const { t, language, setLanguage } = useI18n();

  const isWeb = Platform.OS === 'web';
  const versionDisplay = isWeb ? 'Web (Simulated Android 14)' : 'Android 14 (API 34)';

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <Text style={styles.title}>{t('settingsTitle')}</Text>
      </View>

      {/* Language selection */}
      <View style={styles.sectionHeader}>
        <Globe size={18} color={colors.primary[400]} strokeWidth={2} />
        <Text style={styles.sectionTitle}>{t('selectLanguage')}</Text>
      </View>
      <View style={styles.section}>
        {languages.map((lang, i) => (
          <Pressable
            key={lang.code}
            style={[styles.langRow, i < languages.length - 1 && styles.langRowBorder]}
            onPress={() => setLanguage(lang.code as Language)}>
            <View style={styles.langFlagWrap}>
              <Text style={styles.langFlag}>{lang.flag}</Text>
            </View>
            <Text style={styles.langName}>{lang.nativeName}</Text>
            {language === lang.code && (
              <View style={styles.checkWrap}>
                <Check size={18} color={colors.success[400]} strokeWidth={2.5} />
              </View>
            )}
          </Pressable>
        ))}
      </View>

      {/* Android version info */}
      <View style={styles.sectionHeader}>
        <Smartphone size={18} color={colors.accent[400]} strokeWidth={2} />
        <Text style={styles.sectionTitle}>{t('androidVersion')}</Text>
      </View>
      <View style={styles.section}>
        <View style={styles.infoRow}>
          <View style={styles.infoLeft}>
            <Text style={styles.infoLabel}>{t('currentVersion')}</Text>
          </View>
          <Text style={styles.infoValue}>{versionDisplay}</Text>
        </View>
        <View style={[styles.infoRow, styles.infoRowBorder]}>
          <View style={styles.infoLeft}>
            <Text style={styles.infoLabel}>{t('minVersion')}</Text>
          </View>
          <View style={styles.minVersionBadge}>
            <Text style={styles.minVersionText}>{t('minVersionValue')}</Text>
          </View>
        </View>
      </View>

      {/* General settings */}
      <View style={styles.sectionHeader}>
        <Shield size={18} color={colors.success[400]} strokeWidth={2} />
        <Text style={styles.sectionTitle}>{t('securitySettings')}</Text>
      </View>
      <View style={styles.section}>
        <ToggleRow label={t('realTimeScan')} desc={t('realTimeScanDesc')} icon={<Wifi size={20} color={colors.primary[400]} strokeWidth={2} />} defaultOn />
        <View style={styles.divider} />
        <ToggleRow label={t('apkGuard')} desc={t('apkGuardDesc')} icon={<Shield size={20} color={colors.accent[400]} strokeWidth={2} />} defaultOn />
        <View style={styles.divider} />
        <ToggleRow label={t('sandboxIsolation')} desc={t('sandboxIsolationDesc')} icon={<Shield size={20} color={colors.success[400]} strokeWidth={2} />} defaultOn />
      </View>

      {/* About */}
      <View style={styles.sectionHeader}>
        <Info size={18} color={colors.warning[400]} strokeWidth={2} />
        <Text style={styles.sectionTitle}>{t('about')}</Text>
      </View>
      <View style={styles.aboutCard}>
        <LinearGradient colors={[colors.secondary[900], colors.neutral[900]]} style={styles.aboutGradient}>
          <View style={styles.aboutIconWrap}>
            <Shield size={28} color={colors.primary[400]} strokeWidth={2} />
          </View>
          <Text style={styles.aboutTitle}>Qalqon.uz</Text>
          <Text style={styles.aboutDesc}>{t('aboutDesc')}</Text>
          <View style={styles.aboutVersionRow}>
            <Text style={styles.aboutVersionLabel}>{t('version')}</Text>
            <Text style={styles.aboutVersionValue}>1.0.0</Text>
          </View>
        </LinearGradient>
      </View>
    </ScrollView>
  );
}

function ToggleRow({ label, desc, icon, defaultOn }: { label: string; desc: string; icon: React.ReactNode; defaultOn?: boolean }) {
  return (
    <Pressable style={styles.toggleRow}>
      <View style={styles.toggleLeft}>
        <View style={styles.toggleIconWrap}>{icon}</View>
        <View>
          <Text style={styles.toggleLabel}>{label}</Text>
          <Text style={styles.toggleDesc}>{desc}</Text>
        </View>
      </View>
      <View style={[styles.toggleSwitch, defaultOn && styles.toggleSwitchOn]}>
        <View style={[styles.toggleKnob, defaultOn && styles.toggleKnobOn]} />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.neutral[950] },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl },
  header: { marginBottom: spacing.lg },
  title: {
    fontFamily: typography.heading,
    fontSize: 24,
    color: colors.neutral[0],
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.sm,
    marginTop: spacing.lg,
  },
  sectionTitle: {
    fontFamily: typography.body,
    fontSize: 14,
    fontWeight: '600',
    color: colors.neutral[300],
  },
  section: {
    backgroundColor: colors.neutral[900],
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.neutral[800],
    overflow: 'hidden',
  },
  langRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.md,
    gap: spacing.md,
  },
  langRowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral[800],
  },
  langFlagWrap: {
    width: 40, height: 40,
    borderRadius: 8,
    backgroundColor: colors.neutral[800],
    alignItems: 'center',
    justifyContent: 'center',
  },
  langFlag: {
    fontFamily: typography.heading,
    fontSize: 13,
    fontWeight: '700',
    color: colors.primary[300],
  },
  langName: {
    flex: 1,
    fontFamily: typography.body,
    fontSize: 15,
    color: colors.neutral[100],
  },
  checkWrap: {
    width: 28, height: 28,
    borderRadius: 14,
    backgroundColor: colors.success[900],
    alignItems: 'center',
    justifyContent: 'center',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: spacing.md,
  },
  infoRowBorder: {
    borderTopWidth: 1,
    borderTopColor: colors.neutral[800],
  },
  infoLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  infoLabel: {
    fontFamily: typography.body,
    fontSize: 14,
    color: colors.neutral[200],
  },
  infoValue: {
    fontFamily: typography.body,
    fontSize: 13,
    color: colors.neutral[400],
  },
  minVersionBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 6,
    backgroundColor: colors.success[900],
    borderWidth: 1,
    borderColor: colors.success[700],
  },
  minVersionText: {
    fontFamily: typography.body,
    fontSize: 12,
    fontWeight: '600',
    color: colors.success[300],
  },
  divider: { height: 1, backgroundColor: colors.neutral[800] },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: spacing.md,
  },
  toggleLeft: { flexDirection: 'row', gap: spacing.md, flex: 1 },
  toggleIconWrap: {
    width: 40, height: 40,
    borderRadius: 10,
    backgroundColor: colors.neutral[800],
    alignItems: 'center',
    justifyContent: 'center',
  },
  toggleLabel: {
    fontFamily: typography.body,
    fontSize: 14,
    fontWeight: '500',
    color: colors.neutral[100],
  },
  toggleDesc: {
    fontFamily: typography.body,
    fontSize: 12,
    color: colors.neutral[400],
    marginTop: 2,
  },
  toggleSwitch: {
    width: 44, height: 26,
    borderRadius: 13,
    backgroundColor: colors.neutral[700],
    padding: 3,
    justifyContent: 'center',
  },
  toggleSwitchOn: { backgroundColor: colors.success[600] },
  toggleKnob: {
    width: 20, height: 20,
    borderRadius: 10,
    backgroundColor: colors.neutral[0],
    alignSelf: 'flex-start',
  },
  toggleKnobOn: { alignSelf: 'flex-end' },
  aboutCard: {
    borderRadius: radius.lg,
    overflow: 'hidden',
  },
  aboutGradient: {
    padding: spacing.lg,
    alignItems: 'center',
  },
  aboutIconWrap: {
    width: 64, height: 64,
    borderRadius: 16,
    backgroundColor: colors.neutral[800],
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.md,
  },
  aboutTitle: {
    fontFamily: typography.heading,
    fontSize: 22,
    color: colors.neutral[0],
    marginBottom: spacing.sm,
  },
  aboutDesc: {
    fontFamily: typography.body,
    fontSize: 13,
    lineHeight: 20,
    color: colors.neutral[300],
    textAlign: 'center',
    marginBottom: spacing.lg,
  },
  aboutVersionRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    alignItems: 'center',
  },
  aboutVersionLabel: {
    fontFamily: typography.body,
    fontSize: 12,
    color: colors.neutral[500],
  },
  aboutVersionValue: {
    fontFamily: typography.body,
    fontSize: 12,
    fontWeight: '600',
    color: colors.primary[300],
  },
});

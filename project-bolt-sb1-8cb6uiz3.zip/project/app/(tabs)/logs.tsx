import { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  Pressable,
  Alert,
} from 'react-native';
import {
  Ban,
  Box,
  CheckCircle2,
  ScanLine,
  FileSearch,
  Shield,
  Trash2,
  ScrollText,
} from 'lucide-react-native';
import { useI18n } from '@/lib/i18nContext';
import { colors, spacing, radius, typography } from '@/lib/theme';
import { fetchLogs, clearAllLogs, deleteLog } from '@/lib/logs';
import type { SecurityLog } from '@/lib/supabase';

const EVENT_META: Record<string, { icon: React.ReactNode; color: string }> = {
  apk_blocked: { icon: <Ban size={16} color={colors.error[400]} strokeWidth={2} />, color: colors.error[400] },
  sandbox_redirect: { icon: <Box size={16} color={colors.warning[400]} strokeWidth={2} />, color: colors.warning[400] },
  file_scanning: { icon: <ScanLine size={16} color={colors.accent[400]} strokeWidth={2} />, color: colors.accent[400] },
  file_approved: { icon: <CheckCircle2 size={16} color={colors.success[400]} strokeWidth={2} />, color: colors.success[400] },
  scan_started: { icon: <FileSearch size={16} color={colors.primary[400]} strokeWidth={2} />, color: colors.primary[400] },
  scan_complete: { icon: <Shield size={16} color={colors.primary[300]} strokeWidth={2} />, color: colors.primary[300] },
  protection_enabled: { icon: <Shield size={16} color={colors.success[400]} strokeWidth={2} />, color: colors.success[400] },
  protection_disabled: { icon: <Shield size={16} color={colors.warning[400]} strokeWidth={2} />, color: colors.warning[400] },
};

export default function LogsScreen() {
  const { t } = useI18n();
  const [logs, setLogs] = useState<SecurityLog[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const loadLogs = useCallback(async () => {
    const data = await fetchLogs(50);
    setLogs(data);
  }, []);

  useEffect(() => {
    loadLogs();
  }, [loadLogs]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadLogs();
    setRefreshing(false);
  }, [loadLogs]);

  const handleClear = () => {
    Alert.alert(t('clearLogs'), '', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: t('clearLogs'),
        style: 'destructive',
        onPress: async () => {
          await clearAllLogs();
          loadLogs();
        },
      },
    ]);
  };

  const handleDelete = async (id: string) => {
    await deleteLog(id);
    loadLogs();
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary[400]} />}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>{t('logsTitle')}</Text>
          <Text style={styles.desc}>{t('logsDesc')}</Text>
        </View>
        {logs.length > 0 && (
          <Pressable style={styles.clearBtn} onPress={handleClear}>
            <Trash2 size={16} color={colors.error[400]} strokeWidth={2} />
          </Pressable>
        )}
      </View>

      {/* Stats strip */}
      <View style={styles.statsStrip}>
        <View style={styles.statPill}>
          <Text style={styles.statPillValue}>{logs.length}</Text>
          <Text style={styles.statPillLabel}>total</Text>
        </View>
        <View style={styles.statPill}>
          <Ban size={16} color={colors.error[400]} strokeWidth={2} />
          <Text style={[styles.statPillValue, { color: colors.error[400] }]}>
            {logs.filter((l) => l.event_type === 'apk_blocked').length}
          </Text>
          <Text style={styles.statPillLabel}>blocked</Text>
        </View>
        <View style={styles.statPill}>
          <CheckCircle2 size={16} color={colors.success[400]} strokeWidth={2} />
          <Text style={[styles.statPillValue, { color: colors.success[400] }]}>
            {logs.filter((l) => l.event_type === 'file_approved').length}
          </Text>
          <Text style={styles.statPillLabel}>approved</Text>
        </View>
      </View>

      {logs.length === 0 ? (
        <View style={styles.emptyState}>
          <ScrollText size={48} color={colors.neutral[700]} strokeWidth={1.5} />
          <Text style={styles.emptyTitle}>{t('noLogs')}</Text>
          <Text style={styles.emptyDesc}>{t('noLogsDesc')}</Text>
        </View>
      ) : (
        <View style={styles.logList}>
          {logs.map((log) => {
            const meta = EVENT_META[log.event_type] ?? EVENT_META.scan_complete;
            const time = new Date(log.created_at).toLocaleString([], {
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            });
            const eventLabel = (() => {
              switch (log.event_type) {
                case 'apk_blocked': return t('eventBlocked');
                case 'sandbox_redirect': return t('eventRedirect');
                case 'file_scanning': return t('eventScanning');
                case 'file_approved': return t('eventApproved');
                case 'scan_started': return t('eventScanStart');
                case 'scan_complete': return t('eventScanEnd');
                case 'protection_enabled': return t('enableProtection');
                case 'protection_disabled': return t('disableProtection');
                default: return log.event_type;
              }
            })();

            return (
              <View key={log.id} style={styles.logCard}>
                <View style={[styles.logIconWrap, { borderColor: meta.color + '40' }]}>
                  {meta.icon}
                </View>
                <View style={styles.logContent}>
                  <View style={styles.logTopRow}>
                    <Text style={styles.logEvent}>{eventLabel}</Text>
                    <Text style={styles.logTime}>{time}</Text>
                  </View>
                  {log.file_name && (
                    <Text style={styles.logFile} numberOfLines={1}>{log.file_name}</Text>
                  )}
                  {log.details && (
                    <Text style={styles.logDetails} numberOfLines={2}>{log.details}</Text>
                  )}
                  <View style={styles.logMetaRow}>
                    {log.file_source && <Text style={styles.logSource}>{log.file_source}</Text>}
                    {log.android_version && (
                      <View style={styles.versionBadge}>
                        <Text style={styles.versionText}>{log.android_version}</Text>
                      </View>
                    )}
                  </View>
                </View>
                <Pressable style={styles.deleteBtn} onPress={() => handleDelete(log.id)}>
                  <Trash2 size={14} color={colors.neutral[600]} strokeWidth={2} />
                </Pressable>
              </View>
            );
          })}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.neutral[950] },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.lg,
  },
  title: {
    fontFamily: typography.heading,
    fontSize: 24,
    color: colors.neutral[0],
    marginBottom: spacing.xs,
  },
  desc: {
    fontFamily: typography.body,
    fontSize: 14,
    color: colors.neutral[400],
  },
  clearBtn: {
    width: 40, height: 40,
    borderRadius: radius.md,
    backgroundColor: colors.neutral[900],
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.neutral[800],
  },
  statsStrip: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginBottom: spacing.lg,
  },
  statPill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
    backgroundColor: colors.neutral[900],
    borderRadius: radius.md,
    paddingVertical: spacing.sm,
    borderWidth: 1,
    borderColor: colors.neutral[800],
  },
  statPillValue: {
    fontFamily: typography.heading,
    fontSize: 16,
    color: colors.neutral[0],
  },
  statPillLabel: {
    fontFamily: typography.body,
    fontSize: 10,
    color: colors.neutral[500],
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.xxl * 2,
    gap: spacing.md,
  },
  emptyTitle: {
    fontFamily: typography.body,
    fontSize: 18,
    fontWeight: '600',
    color: colors.neutral[300],
  },
  emptyDesc: {
    fontFamily: typography.body,
    fontSize: 13,
    color: colors.neutral[500],
  },
  logList: { gap: spacing.sm },
  logCard: {
    flexDirection: 'row',
    gap: spacing.md,
    backgroundColor: colors.neutral[900],
    borderRadius: radius.lg,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.neutral[800],
  },
  logIconWrap: {
    width: 40, height: 40,
    borderRadius: 10,
    backgroundColor: colors.neutral[800],
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  logContent: { flex: 1 },
  logTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 2,
  },
  logEvent: {
    fontFamily: typography.body,
    fontSize: 13,
    fontWeight: '600',
    color: colors.neutral[100],
  },
  logTime: {
    fontFamily: typography.body,
    fontSize: 11,
    color: colors.neutral[500],
  },
  logFile: {
    fontFamily: typography.body,
    fontSize: 12,
    color: colors.neutral[300],
    marginBottom: 2,
  },
  logDetails: {
    fontFamily: typography.body,
    fontSize: 11,
    lineHeight: 16,
    color: colors.neutral[400],
    marginBottom: spacing.xs,
  },
  logMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  logSource: {
    fontFamily: typography.body,
    fontSize: 10,
    color: colors.neutral[500],
  },
  versionBadge: {
    paddingHorizontal: spacing.xs,
    paddingVertical: 2,
    borderRadius: 4,
    backgroundColor: colors.neutral[800],
  },
  versionText: {
    fontFamily: typography.body,
    fontSize: 9,
    color: colors.neutral[400],
  },
  deleteBtn: {
    width: 32, height: 32,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'flex-start',
  },
});

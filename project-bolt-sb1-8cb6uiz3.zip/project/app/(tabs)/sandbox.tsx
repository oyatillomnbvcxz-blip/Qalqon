import { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withDelay,
} from 'react-native-reanimated';
import { Box, FileWarning, Shield, Trash2, Unlock, Layers, Atom, Waves } from 'lucide-react-native';
import { useI18n } from '@/lib/i18nContext';
import { colors, spacing, radius, typography } from '@/lib/theme';
import { fetchLogs, deleteLog } from '@/lib/logs';
import type { SecurityLog } from '@/lib/supabase';

export default function SandboxScreen() {
  const { t } = useI18n();
  const [refreshing, setRefreshing] = useState(false);
  const [logs, setLogs] = useState<SecurityLog[]>([]);

  const loadLogs = useCallback(async () => {
    const data = await fetchLogs(50);
    const isolated = data.filter(
      (l) => l.event_type === 'sandbox_redirect' || l.event_type === 'file_scanning',
    );
    setLogs(isolated);
  }, []);

  useEffect(() => {
    loadLogs();
  }, [loadLogs]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadLogs();
    setRefreshing(false);
  }, [loadLogs]);

  // Animated sandbox visualization particles
  const particle1 = useSharedValue(0);
  const particle2 = useSharedValue(0);
  const particle3 = useSharedValue(0);
  const wallGlow = useSharedValue(0);

  useEffect(() => {
    particle1.value = withRepeat(withTiming(1, { duration: 3000 }), -1, true);
    particle2.value = withDelay(1000, withRepeat(withTiming(1, { duration: 2500 }), -1, true));
    particle3.value = withDelay(2000, withRepeat(withTiming(1, { duration: 3500 }), -1, true));
    wallGlow.value = withRepeat(withTiming(1, { duration: 2000 }), -1, true);
  }, []);

  const p1Style = useAnimatedStyle(() => ({
    transform: [{ translateX: particle1.value * 120 - 60 }, { translateY: Math.sin(particle1.value * 6) * 20 }],
    opacity: 0.3 + particle1.value * 0.4,
  }));
  const p2Style = useAnimatedStyle(() => ({
    transform: [{ translateX: particle2.value * 100 - 50 }, { translateY: Math.cos(particle2.value * 5) * 25 }],
    opacity: 0.3 + particle2.value * 0.4,
  }));
  const p3Style = useAnimatedStyle(() => ({
    transform: [{ translateX: particle3.value * 140 - 70 }, { translateY: Math.sin(particle3.value * 4) * 30 }],
    opacity: 0.3 + particle3.value * 0.4,
  }));
  const wallStyle = useAnimatedStyle(() => ({
    opacity: 0.15 + wallGlow.value * 0.35,
  }));

  const handleRelease = async (log: SecurityLog) => {
    await deleteLog(log.id);
    loadLogs();
  };

  const handleDelete = async (log: SecurityLog) => {
    await deleteLog(log.id);
    loadLogs();
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.accent[400]} />}>
      <View style={styles.header}>
        <Text style={styles.title}>{t('sandboxTitle')}</Text>
        <Text style={styles.desc}>{t('sandboxDesc')}</Text>
      </View>

      {/* Sandbox visualization */}
      <View style={styles.sandboxViz}>
        <LinearGradient
          colors={[colors.neutral[900], colors.secondary[900], colors.neutral[900]]}
          style={styles.sandboxGradient}
        />
        {/* Isolation walls */}
        <Animated.View style={[styles.wallTop, wallStyle]} />
        <Animated.View style={[styles.wallBottom, wallStyle]} />
        <Animated.View style={[styles.wallLeft, wallStyle]} />
        <Animated.View style={[styles.wallRight, wallStyle]} />

        {/* Center icon */}
        <View style={styles.sandboxCore}>
          <LinearGradient colors={[colors.accent[500], colors.accent[700]]} style={styles.coreCircle}>
            <Atom size={32} color={colors.neutral[0]} strokeWidth={1.5} />
          </LinearGradient>
          <Text style={styles.coreLabel}>QUMLOQ</Text>
          <Text style={styles.coreSubLabel}>KERNEL ISOLATION</Text>
        </View>

        {/* Floating particles */}
        <Animated.View style={[styles.particle, styles.particle1, p1Style]}>
          <FileWarning size={20} color={colors.warning[400]} strokeWidth={2} />
        </Animated.View>
        <Animated.View style={[styles.particle, styles.particle2, p2Style]}>
          <FileWarning size={16} color={colors.error[400]} strokeWidth={2} />
        </Animated.View>
        <Animated.View style={[styles.particle, styles.particle3, p3Style]}>
          <FileWarning size={18} color={colors.warning[300]} strokeWidth={2} />
        </Animated.View>

        {/* Wave overlay */}
        <Waves
          size={200}
          color={colors.accent[400]}
          strokeWidth={1}
          absoluteStrokeWidth
          style={styles.waveOverlay}
        />
      </View>

      {/* Isolation status */}
      <View style={styles.statusBar}>
        <View style={styles.statusItem}>
          <Shield size={16} color={colors.success[400]} strokeWidth={2} />
          <Text style={styles.statusText}>Kernel isolated</Text>
        </View>
        <View style={styles.statusItem}>
          <Layers size={16} color={colors.accent[400]} strokeWidth={2} />
          <Text style={styles.statusText}>{logs.length} files contained</Text>
        </View>
      </View>

      {/* Isolated files list */}
      <View style={styles.sectionHeader}>
        <Box size={18} color={colors.neutral[300]} strokeWidth={2} />
        <Text style={styles.sectionTitle}>{t('isolatedFiles')}</Text>
      </View>

      <View style={styles.fileList}>
        {logs.length === 0 && (
          <View style={styles.emptyState}>
            <Box size={40} color={colors.neutral[700]} strokeWidth={1.5} />
            <Text style={styles.emptyTitle}>{t('sandboxEmpty')}</Text>
            <Text style={styles.emptyDesc}>{t('sandboxEmptyDesc')}</Text>
          </View>
        )}
        {logs.map((log) => (
          <View key={log.id} style={styles.fileCard}>
            <View style={styles.fileIconWrap}>
              <LinearGradient colors={[colors.warning[600], colors.error[700]]} style={styles.fileIconGradient}>
                <FileWarning size={22} color={colors.neutral[0]} strokeWidth={2} />
              </LinearGradient>
            </View>
            <View style={styles.fileInfo}>
              <Text style={styles.fileName} numberOfLines={1}>{log.file_name ?? 'Unknown'}</Text>
              <Text style={styles.fileSource}>{log.file_source ?? 'Unknown source'}</Text>
              <Text style={styles.fileTimestamp}>
                {new Date(log.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
              </Text>
            </View>
            <View style={styles.fileActions}>
              <Pressable style={styles.fileActionBtn} onPress={() => handleRelease(log)}>
                <Unlock size={16} color={colors.success[400]} strokeWidth={2} />
              </Pressable>
              <Pressable style={styles.fileActionBtn} onPress={() => handleDelete(log)}>
                <Trash2 size={16} color={colors.error[400]} strokeWidth={2} />
              </Pressable>
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.neutral[950] },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl },
  header: { marginBottom: spacing.lg },
  title: {
    fontFamily: typography.heading,
    fontSize: 24,
    color: colors.neutral[0],
    marginBottom: spacing.xs,
  },
  desc: {
    fontFamily: typography.body,
    fontSize: 14,
    color: colors.neutral[400],
    lineHeight: 20,
  },
  sandboxViz: {
    height: 240,
    borderRadius: radius.xl,
    backgroundColor: colors.neutral[900],
    borderWidth: 1,
    borderColor: colors.neutral[800],
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.md,
  },
  sandboxGradient: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
  },
  wallTop: { position: 'absolute', top: 0, left: 0, right: 0, height: 2, backgroundColor: colors.accent[400] },
  wallBottom: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 2, backgroundColor: colors.accent[400] },
  wallLeft: { position: 'absolute', top: 0, bottom: 0, left: 0, width: 2, backgroundColor: colors.accent[400] },
  wallRight: { position: 'absolute', top: 0, bottom: 0, right: 0, width: 2, backgroundColor: colors.accent[400] },
  sandboxCore: { alignItems: 'center', zIndex: 5 },
  coreCircle: {
    width: 64, height: 64,
    borderRadius: 32,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.sm,
  },
  coreLabel: {
    fontFamily: typography.heading,
    fontSize: 14,
    color: colors.accent[300],
    letterSpacing: 3,
  },
  coreSubLabel: {
    fontFamily: typography.body,
    fontSize: 8,
    color: colors.neutral[500],
    letterSpacing: 2,
    marginTop: 2,
  },
  particle: { position: 'absolute', zIndex: 3 },
  particle1: { top: 50, left: 80 },
  particle2: { top: 150, left: 100 },
  particle3: { top: 90, left: 180 },
  waveOverlay: { position: 'absolute', opacity: 0.15 },
  statusBar: {
    flexDirection: 'row',
    gap: spacing.md,
    marginBottom: spacing.lg,
  },
  statusItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    backgroundColor: colors.neutral[900],
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.neutral[800],
  },
  statusText: {
    fontFamily: typography.body,
    fontSize: 12,
    color: colors.neutral[200],
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  sectionTitle: {
    fontFamily: typography.body,
    fontSize: 15,
    fontWeight: '600',
    color: colors.neutral[200],
  },
  fileList: { gap: spacing.md },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.xxl,
    gap: spacing.sm,
  },
  emptyTitle: {
    fontFamily: typography.body,
    fontSize: 16,
    fontWeight: '600',
    color: colors.neutral[300],
  },
  emptyDesc: {
    fontFamily: typography.body,
    fontSize: 13,
    color: colors.neutral[500],
  },
  fileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.neutral[900],
    borderRadius: radius.lg,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.neutral[800],
  },
  fileIconWrap: {},
  fileIconGradient: {
    width: 44, height: 44,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fileInfo: { flex: 1 },
  fileName: {
    fontFamily: typography.body,
    fontSize: 14,
    fontWeight: '600',
    color: colors.neutral[100],
  },
  fileSource: {
    fontFamily: typography.body,
    fontSize: 12,
    color: colors.neutral[400],
    marginTop: 2,
  },
  fileTimestamp: {
    fontFamily: typography.body,
    fontSize: 11,
    color: colors.neutral[500],
    marginTop: 2,
  },
  fileActions: { flexDirection: 'row', gap: spacing.sm },
  fileActionBtn: {
    width: 36, height: 36,
    borderRadius: 8,
    backgroundColor: colors.neutral[800],
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.neutral[700],
  },
});

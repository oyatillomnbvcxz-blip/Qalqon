import { useState, useRef, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withSequence,
  cancelAnimation,
  Easing,
} from 'react-native-reanimated';
import {
  ScanLine,
  FileSearch,
  Ban,
  Box,
  CheckCircle2,
  AlertTriangle,
  FileCheck2,
  Shield,
} from 'lucide-react-native';
import { useI18n } from '@/lib/i18nContext';
import { colors, spacing, radius, typography } from '@/lib/theme';
import { insertLog } from '@/lib/logs';

type ScanPhase = 'idle' | 'scanning' | 'isolating' | 'complete';
type Verdict = 'safe' | 'danger' | null;

const SIM_FILES = [
  { name: 'game_mod.apk', source: 'Side load', danger: true },
  { name: 'photo_viewer.apk', source: 'Browser download', danger: false },
  { name: 'update_v2.apk', source: 'Play Store', danger: false },
  { name: 'free_app.apk', source: 'Side load', danger: true },
  { name: 'document_reader.apk', source: 'Play Store', danger: false },
];

export default function ScannerScreen() {
  const { t } = useI18n();
  const [phase, setPhase] = useState<ScanPhase>('idle');
  const [verdict, setVerdict] = useState<Verdict>(null);
  const [progress, setProgress] = useState(0);
  const [currentFile, setCurrentFile] = useState<string | null>(null);
  const [stepIndex, setStepIndex] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const scanLineAnim = useSharedValue(0);

  const steps = [
    { icon: <FileSearch size={20} color={colors.primary[300]} strokeWidth={2} />, label: t('signatureCheck') },
    { icon: <ScanLine size={20} color={colors.accent[300]} strokeWidth={2} />, label: t('deepScan') },
    { icon: <Box size={20} color={colors.success[300]} strokeWidth={2} />, label: t('behaviorAnalysis') },
  ];

  const stopAnimation = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    cancelAnimation(scanLineAnim);
  };

  const runScan = useCallback(async () => {
    setPhase('scanning');
    setVerdict(null);
    setProgress(0);
    setStepIndex(0);

    const file = SIM_FILES[Math.floor(Math.random() * SIM_FILES.length)];
    setCurrentFile(file.name);

    await insertLog({
      event_type: 'scan_started',
      file_name: file.name,
      file_source: file.source,
      details: t('scanTitle'),
      threat_level: 'safe',
    });

    let prog = 0;
    timerRef.current = setInterval(() => {
      prog += 2;
      setProgress(prog);
      if (prog <= 33) setStepIndex(0);
      else if (prog <= 66) setStepIndex(1);
      else setStepIndex(2);

      if (prog >= 100) {
        stopAnimation();
        setPhase('isolating');
        setTimeout(async () => {
          setPhase('complete');
          const isDanger = file.danger;
          setVerdict(isDanger ? 'danger' : 'safe');

          if (isDanger) {
            await insertLog({
              event_type: 'apk_blocked',
              file_name: file.name,
              file_source: file.source,
              details: t('apkBlocked'),
              threat_level: 'danger',
            });
            await insertLog({
              event_type: 'sandbox_redirect',
              file_name: file.name,
              file_source: file.source,
              details: t('sandboxRedirect'),
              threat_level: 'warning',
            });
          } else {
            await insertLog({
              event_type: 'file_approved',
              file_name: file.name,
              file_source: file.source,
              details: t('fileApproved'),
              threat_level: 'safe',
            });
          }
          await insertLog({
            event_type: 'scan_complete',
            file_name: file.name,
            file_source: file.source,
            details: isDanger ? t('verdictDanger') : t('verdictSafe'),
            threat_level: isDanger ? 'danger' : 'safe',
          });
        }, 1500);
      }
    }, 80);
  }, [t]);

  useEffect(() => {
    if (phase === 'scanning' || phase === 'isolating') {
      scanLineAnim.value = withRepeat(
        withSequence(
          withTiming(1, { duration: 1500, easing: Easing.inOut(Easing.ease) }),
          withTiming(0, { duration: 1500, easing: Easing.inOut(Easing.ease) }),
        ),
        -1,
      );
    } else {
      cancelAnimation(scanLineAnim);
    }
    return () => cancelAnimation(scanLineAnim);
  }, [phase]);

  useEffect(() => () => stopAnimation(), []);

  const scanBarStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: scanLineAnim.value * 220 - 110 }],
  }));

  const isBusy = phase === 'scanning' || phase === 'isolating';

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Scan viewport */}
      <View style={styles.scanViewport}>
        <LinearGradient
          colors={
            verdict === 'danger'
              ? [colors.neutral[900], colors.error[900], colors.neutral[900]]
              : verdict === 'safe'
                ? [colors.neutral[900], colors.success[900], colors.neutral[900]]
                : [colors.neutral[900], colors.secondary[800], colors.neutral[900]]
          }
          style={styles.scanGradient}
        />
        <View style={styles.scanTargetWrap}>
          {phase === 'idle' && (
            <View style={styles.idleIcon}>
              <ScanLine size={56} color={colors.neutral[500]} strokeWidth={1.5} />
              <Text style={styles.scanTargetText}>{t('selectFileDesc')}</Text>
            </View>
          )}
          {(phase === 'scanning' || phase === 'isolating') && (
            <>
              <View style={styles.scanningIcon}>
                {phase === 'scanning' ? (
                  <FileSearch size={56} color={colors.primary[300]} strokeWidth={2} />
                ) : (
                  <Box size={56} color={colors.warning[400]} strokeWidth={2} />
                )}
              </View>
              <Text style={styles.scanningFileName}>{currentFile}</Text>
              <Text style={styles.scanningPhaseText}>
                {phase === 'scanning' ? t('fileScanning') : t('sandboxRedirect')}
              </Text>
            </>
          )}
          {phase === 'complete' && (
            <View style={styles.verdictWrap}>
              {verdict === 'safe' ? (
                <LinearGradient colors={[colors.success[500], colors.success[700]]} style={styles.verdictCircle}>
                  <CheckCircle2 size={60} color={colors.neutral[0]} strokeWidth={2} />
                </LinearGradient>
              ) : (
                <LinearGradient colors={[colors.error[500], colors.error[700]]} style={styles.verdictCircle}>
                  <AlertTriangle size={60} color={colors.neutral[0]} strokeWidth={2} />
                </LinearGradient>
              )}
              <Text style={[styles.verdictText, verdict === 'safe' ? styles.verdictSafe : styles.verdictDanger]}>
                {verdict === 'safe' ? t('verdictSafe') : t('verdictDanger')}
              </Text>
              <Text style={styles.verdictFileName}>{currentFile}</Text>
              <Text style={styles.verdictDetail}>
                {verdict === 'safe' ? t('fileApproved') : t('apkBlocked')}
              </Text>
            </View>
          )}
        </View>

        {/* Scan line animation */}
        {isBusy && (
          <Animated.View style={[styles.scanLine, scanBarStyle]}>
            <LinearGradient
              colors={['transparent', colors.primary[400], 'transparent']}
              style={styles.scanLineGradient}
            />
          </Animated.View>
        )}
      </View>

      {/* Progress */}
      {isBusy && (
        <View style={styles.progressSection}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: `${progress}%` }]} />
          </View>
          <Text style={styles.progressText}>{progress}%</Text>
        </View>
      )}

      {/* Steps */}
      {(isBusy || phase === 'complete') && (
        <View style={styles.stepsRow}>
          {steps.map((step, i) => (
            <View key={i} style={[styles.step, (i <= stepIndex || phase === 'complete') && styles.stepActive]}>
              {step.icon}
              <Text style={[styles.stepLabel, (i <= stepIndex || phase === 'complete') && styles.stepLabelActive]}>
                {step.label}
              </Text>
              {i < stepIndex || phase === 'complete' ? (
                <CheckCircle2 size={14} color={colors.success[400]} strokeWidth={2} />
              ) : i === stepIndex ? (
                <View style={styles.stepSpinner} />
              ) : (
                <View style={styles.stepDot} />
              )}
            </View>
          ))}
        </View>
      )}

      {/* Action buttons */}
      <View style={styles.actions}>
        {phase === 'idle' || phase === 'complete' ? (
          <Pressable style={styles.actionButton} onPress={runScan}>
            <LinearGradient colors={[colors.primary[600], colors.primary[800]]} style={styles.actionGradient}>
              {phase === 'complete' ? (
                <FileCheck2 size={20} color={colors.neutral[0]} strokeWidth={2} />
              ) : (
                <ScanLine size={20} color={colors.neutral[0]} strokeWidth={2} />
              )}
              <Text style={styles.actionText}>
                {phase === 'complete' ? t('scanAgain') : t('runSimulation')}
              </Text>
            </LinearGradient>
          </Pressable>
        ) : (
          <Pressable style={[styles.actionButton, styles.actionButtonBusy]} onPress={stopAnimation}>
            <View style={styles.actionGradient}>
              <Ban size={20} color={colors.error[400]} strokeWidth={2} />
              <Text style={[styles.actionText, { color: colors.error[400] }]}>Cancel</Text>
            </View>
          </Pressable>
        )}
      </View>

      {/* Simulation files info */}
      <View style={styles.infoCard}>
        <View style={styles.infoHeader}>
          <Shield size={16} color={colors.primary[400]} strokeWidth={2} />
          <Text style={styles.infoTitle}>Simulated files</Text>
        </View>
        <Text style={styles.infoDesc}>
          This scanner simulates APK inspection. Tap the button above to run a random file through the scan pipeline.
          Dangerous files are blocked and redirected to the sandbox.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.neutral[950] },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl },
  scanViewport: {
    height: 280,
    borderRadius: radius.xl,
    backgroundColor: colors.neutral[900],
    borderWidth: 1,
    borderColor: colors.neutral[800],
    overflow: 'hidden',
    marginBottom: spacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scanGradient: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
  },
  scanTargetWrap: {
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 2,
    paddingHorizontal: spacing.lg,
  },
  idleIcon: { alignItems: 'center', gap: spacing.md },
  scanTargetText: {
    fontFamily: typography.body,
    fontSize: 13,
    color: colors.neutral[500],
    textAlign: 'center',
  },
  scanningIcon: { marginBottom: spacing.md },
  scanningFileName: {
    fontFamily: typography.body,
    fontSize: 16,
    fontWeight: '600',
    color: colors.neutral[100],
    marginBottom: spacing.xs,
  },
  scanningPhaseText: {
    fontFamily: typography.body,
    fontSize: 12,
    color: colors.neutral[400],
    textAlign: 'center',
  },
  verdictWrap: { alignItems: 'center', gap: spacing.sm },
  verdictCircle: {
    width: 110, height: 110,
    borderRadius: 55,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.sm,
  },
  verdictText: {
    fontFamily: typography.heading,
    fontSize: 22,
  },
  verdictSafe: { color: colors.success[400] },
  verdictDanger: { color: colors.error[400] },
  verdictFileName: {
    fontFamily: typography.body,
    fontSize: 14,
    fontWeight: '500',
    color: colors.neutral[100],
  },
  verdictDetail: {
    fontFamily: typography.body,
    fontSize: 12,
    color: colors.neutral[400],
    textAlign: 'center',
    marginTop: spacing.xs,
  },
  scanLine: {
    position: 'absolute',
    left: 0, right: 0,
    height: 3,
    zIndex: 3,
  },
  scanLineGradient: { flex: 1, height: 3 },
  progressSection: { marginBottom: spacing.lg },
  progressBar: {
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.neutral[800],
    overflow: 'hidden',
  },
  progressFill: {
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.primary[400],
  },
  progressText: {
    fontFamily: typography.body,
    fontSize: 12,
    color: colors.neutral[400],
    textAlign: 'right',
    marginTop: spacing.xs,
  },
  stepsRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginBottom: spacing.lg,
  },
  step: {
    flex: 1,
    backgroundColor: colors.neutral[900],
    borderRadius: radius.md,
    padding: spacing.md,
    alignItems: 'center',
    gap: spacing.xs,
    borderWidth: 1,
    borderColor: colors.neutral[800],
  },
  stepActive: { borderColor: colors.primary[600] },
  stepLabel: {
    fontFamily: typography.body,
    fontSize: 11,
    color: colors.neutral[500],
    textAlign: 'center',
  },
  stepLabelActive: { color: colors.neutral[200] },
  stepSpinner: {
    width: 14, height: 14,
    borderRadius: 7,
    borderWidth: 2,
    borderColor: colors.primary[400],
    borderTopColor: 'transparent',
  },
  stepDot: {
    width: 14, height: 14,
    borderRadius: 7,
    backgroundColor: colors.neutral[700],
  },
  actions: { marginBottom: spacing.lg },
  actionButton: { borderRadius: radius.lg, overflow: 'hidden' },
  actionButtonBusy: { backgroundColor: colors.neutral[800], borderWidth: 1, borderColor: colors.error[700] },
  actionGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
  },
  actionText: {
    fontFamily: typography.body,
    fontSize: 15,
    fontWeight: '600',
    color: colors.neutral[0],
  },
  infoCard: {
    backgroundColor: colors.neutral[900],
    borderRadius: radius.lg,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.neutral[800],
  },
  infoHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  infoTitle: {
    fontFamily: typography.body,
    fontSize: 14,
    fontWeight: '600',
    color: colors.neutral[200],
  },
  infoDesc: {
    fontFamily: typography.body,
    fontSize: 12,
    lineHeight: 18,
    color: colors.neutral[400],
  },
});

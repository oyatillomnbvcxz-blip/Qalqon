import { Tabs } from 'expo-router';
import { Shield, ScanLine, Box, ScrollText, Settings } from 'lucide-react-native';
import { useI18n } from '@/lib/i18nContext';
import { colors } from '@/lib/theme';

export default function TabLayout() {
  const { t } = useI18n();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: colors.neutral[900],
          borderTopColor: colors.neutral[800],
          borderTopWidth: 1,
          height: 64,
          paddingBottom: 8,
          paddingTop: 8,
        },
        tabBarActiveTintColor: colors.primary[400],
        tabBarInactiveTintColor: colors.neutral[400],
        tabBarLabelStyle: {
          fontFamily: 'Inter-Medium',
          fontSize: 11,
        },
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: t('tabDashboard'),
          tabBarIcon: ({ size, color }) => <Shield size={size} color={color} strokeWidth={2} />,
        }}
      />
      <Tabs.Screen
        name="scanner"
        options={{
          title: t('tabScanner'),
          tabBarIcon: ({ size, color }) => <ScanLine size={size} color={color} strokeWidth={2} />,
        }}
      />
      <Tabs.Screen
        name="sandbox"
        options={{
          title: t('tabSandbox'),
          tabBarIcon: ({ size, color }) => <Box size={size} color={color} strokeWidth={2} />,
        }}
      />
      <Tabs.Screen
        name="logs"
        options={{
          title: t('tabLogs'),
          tabBarIcon: ({ size, color }) => <ScrollText size={size} color={color} strokeWidth={2} />,
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: t('tabSettings'),
          tabBarIcon: ({ size, color }) => <Settings size={size} color={color} strokeWidth={2} />,
        }}
      />
    </Tabs>
  );
}

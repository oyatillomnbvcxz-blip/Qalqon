import { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  Pressable,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { useSharedValue, useAnimatedStyle, withRepeat, withTiming, withSequence } from 'react-native-reanimated';
import {
  Shield,
  ShieldCheck,
  ShieldAlert,
  ShieldOff,
  FileSearch,
  Ban,
  Box,
  Activity,
  Zap,
  Power,
} from 'lucide-react-native';
import { useI18n } from '@/lib/i18nContext';
import { colors, spacing, radius, typography } from '@/lib/theme';
import { fetchLogs, insertLog } from '@/lib/logs';
import type { SecurityLog } from '@/lib/supabase';

type ThreatLevel = 'safe' | 'danger';

export default function DashboardScreen() {
  const { t } = useI18n();
  const [protectionOn, setProtectionOn] = useState(true);
  const [logs, setLogs] = useState<SecurityLog[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const loadLogs = useCallback(async () => {
    const data = await fetchLogs(20);
    setLogs(data);
  }, []);

  useEffect(() => {
    loadLogs();
  }, [loadLogs]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadLogs();
    setRefreshing(false);
  }, [loadLogs]);

  const hasDanger = logs.some(
    (l) => l.threat_level === 'danger' && Date.now() - new Date(l.created_at).getTime() < 60000,
  );
  const threatLevel: ThreatLevel = protectionOn && !hasDanger ? 'safe' : 'danger';

  const blockedCount = logs.filter((l) => l.event_type === 'apk_blocked').length;
  const sandboxCount = logs.filter(
    (l) => l.event_type === 'sandbox_redirect' || l.event_type === 'file_scanning',
  ).length;
  const scansToday = logs.length;

  const toggleProtection = () => {
    const newState = !protectionOn;
    setProtectionOn(newState);
    insertLog({
      event_type: newState ? 'protection_enabled' : 'protection_disabled',
      details: newState ? t('enableProtection') : t('disableProtection'),
      threat_level: newState ? 'safe' : 'warning',
    });
    loadLogs();
  };

  const pulseAnim = useSharedValue(1);
  useEffect(() => {
    if (threatLevel === 'danger') {
      pulseAnim.value = withRepeat(
        withSequence(withTiming(1.15, { duration: 800 }), withTiming(1, { duration: 800 })),
        -1,
      );
    } else {
      pulseAnim.value = withRepeat(withTiming(1.04, { duration: 2000 }), -1, true);
    }
  }, [threatLevel]);

  const shieldAnimStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulseAnim.value }],
  }));

  const gradientColors: [string, string, string] =
    threatLevel === 'safe'
      ? [colors.neutral[950], colors.secondary[900], colors.primary[900]]
      : [colors.neutral[950], colors.error[900], colors.error[800]];

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary[400]} />}>
      <LinearGradient colors={gradientColors} style={styles.heroGradient} />
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <Text style={styles.appTitle}>{t('appTitle')}</Text>
          <View style={styles.langBadge}>
            <Text style={styles.langBadgeText}>UZ</Text>
          </View>
        </View>
      </View>

      {/* Shield status */}
      <View style={styles.shieldSection}>
        <Animated.View style={[styles.shieldWrap, shieldAnimStyle]}>
          {threatLevel === 'safe' ? (
            <LinearGradient
              colors={[colors.success[500], colors.success[700]]}
              style={styles.shieldCircle}>
              <ShieldCheck size={72} color={colors.neutral[0]} strokeWidth={2} />
            </LinearGradient>
          ) : (
            <LinearGradient
              colors={[colors.error[500], colors.error[700]]}
              style={styles.shieldCircle}>
              <ShieldAlert size={72} color={colors.neutral[0]} strokeWidth={2} />
            </LinearGradient>
          )}
        </Animated.View>
        <Text style={[styles.statusText, threatLevel === 'safe' ? styles.statusSafe : styles.statusDanger]}>
          {threatLevel === 'safe' ? t('statusSafe') : t('statusDanger')}
        </Text>
        <View style={[styles.protectionBadge, threatLevel === 'safe' ? styles.badgeSafe : styles.badgeDanger]}>
          {protectionOn ? (
            <ShieldCheck size={14} color={colors.success[400]} strokeWidth={2} />
          ) : (
            <ShieldOff size={14} color={colors.warning[400]} strokeWidth={2} />
          )}
          <Text style={[styles.protectionText, { color: protectionOn ? colors.success[400] : colors.warning[400] }]}>
            {protectionOn ? t('protectionActive') : t('protectionPaused')}
          </Text>
        </View>
      </View>

      {/* Protection toggle */}
      <Pressable style={styles.toggleButton} onPress={toggleProtection}>
        <LinearGradient
          colors={protectionOn ? [colors.primary[600], colors.primary[800]] : [colors.neutral[700], colors.neutral[800]]}
          style={styles.toggleGradient}>
          <Power size={20} color={colors.neutral[0]} strokeWidth={2} />
          <Text style={styles.toggleText}>
            {protectionOn ? t('disableProtection') : t('enableProtection')}
          </Text>
        </LinearGradient>
      </Pressable>

      {/* Feature cards */}
      <View style={styles.featuresRow}>
        <FeatureCard icon={<FileSearch size={22} color={colors.primary[400]} strokeWidth={2} />} title={t('realTimeScan')} desc={t('realTimeScanDesc')} active={protectionOn} />
        <FeatureCard icon={<Ban size={22} color={colors.accent[400]} strokeWidth={2} />} title={t('apkGuard')} desc={t('apkGuardDesc')} active={protectionOn} />
      </View>
      <View style={styles.featuresRow}>
        <FeatureCard icon={<Box size={22} color={colors.success[400]} strokeWidth={2} />} title={t('sandboxIsolation')} desc={t('sandboxIsolationDesc')} active={protectionOn} />
        <FeatureCard icon={<Zap size={22} color={colors.warning[400]} strokeWidth={2} />} title={t('deepScan')} desc={t('behaviorAnalysis')} active={protectionOn} />
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        <StatCard value={scansToday} label={t('scansToday')} color={colors.primary[400]} icon={<Activity size={18} color={colors.primary[400]} strokeWidth={2} />} />
        <StatCard value={blockedCount} label={t('threatsBlocked')} color={colors.error[400]} icon={<Ban size={18} color={colors.error[400]} strokeWidth={2} />} />
        <StatCard value={sandboxCount} label={t('filesInSandbox')} color={colors.accent[400]} icon={<Box size={18} color={colors.accent[400]} strokeWidth={2} />} />
      </View>

      {/* Recent activity */}
      <View style={styles.sectionHeader}>
        <Activity size={18} color={colors.neutral[300]} strokeWidth={2} />
        <Text style={styles.sectionTitle}>{t('recentActivity')}</Text>
      </View>
      <View style={styles.activityList}>
        {logs.length === 0 && (
          <Text style={styles.emptyText}>{t('noLogsDesc')}</Text>
        )}
        {logs.slice(0, 5).map((log) => (
          <ActivityRow key={log.id} log={log} />
        ))}
      </View>
    </ScrollView>
  );
}

function FeatureCard({ icon, title, desc, active }: { icon: React.ReactNode; title: string; desc: string; active: boolean }) {
  return (
    <View style={[styles.featureCard, !active && styles.featureInactive]}>
      <View style={styles.featureIconWrap}>{icon}</View>
      <Text style={styles.featureTitle}>{title}</Text>
      <Text style={styles.featureDesc}>{desc}</Text>
      <View style={[styles.featureStatus, active ? styles.statusDotActive : styles.statusDotInactive]} />
    </View>
  );
}

function StatCard({ value, label, color, icon }: { value: number; label: string; color: string; icon: React.ReactNode }) {
  return (
    <View style={styles.statCard}>
      <View style={styles.statIconWrap}>{icon}</View>
      <Text style={[styles.statValue, { color }]}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

function ActivityRow({ log }: { log: SecurityLog }) {
  const { t } = useI18n();
  const level = log.threat_level ?? 'safe';
  const levelColor = level === 'danger' ? colors.error[400] : level === 'warning' ? colors.warning[400] : colors.success[400];

  let eventLabel = log.event_type;
  if (log.event_type === 'apk_blocked') eventLabel = t('eventBlocked');
  else if (log.event_type === 'sandbox_redirect') eventLabel = t('eventRedirect');
  else if (log.event_type === 'file_scanning') eventLabel = t('eventScanning');
  else if (log.event_type === 'file_approved') eventLabel = t('eventApproved');
  else if (log.event_type === 'scan_started') eventLabel = t('eventScanStart');
  else if (log.event_type === 'scan_complete') eventLabel = t('eventScanEnd');

  const time = new Date(log.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <View style={styles.activityRow}>
      <View style={[styles.activityDot, { backgroundColor: levelColor }]} />
      <View style={styles.activityContent}>
        <Text style={styles.activityEvent}>{eventLabel}</Text>
        {log.file_name && <Text style={styles.activityFile}>{log.file_name}</Text>}
      </View>
      <Text style={styles.activityTime}>{time}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.neutral[950] },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl },
  heroGradient: {
    position: 'absolute',
    top: 0, left: 0, right: 0,
    height: 320,
  },
  header: { paddingTop: spacing.xl },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  appTitle: {
    fontFamily: typography.heading,
    fontSize: 20,
    color: colors.neutral[0],
    flex: 1,
  },
  langBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: radius.pill,
    backgroundColor: colors.neutral[800],
    borderWidth: 1,
    borderColor: colors.neutral[700],
  },
  langBadgeText: {
    fontFamily: typography.body,
    fontSize: 12,
    fontWeight: '600',
    color: colors.primary[300],
  },
  shieldSection: { alignItems: 'center', marginTop: spacing.xl, marginBottom: spacing.lg },
  shieldWrap: { marginBottom: spacing.md },
  shieldCircle: {
    width: 130, height: 130,
    borderRadius: 65,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.primary[400],
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 8,
  },
  statusText: {
    fontFamily: typography.heading,
    fontSize: 22,
    marginBottom: spacing.sm,
  },
  statusSafe: { color: colors.success[400] },
  statusDanger: { color: colors.error[400] },
  protectionBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: radius.pill,
  },
  badgeSafe: { backgroundColor: colors.success[900] + '80' },
  badgeDanger: { backgroundColor: colors.error[900] + '80' },
  protectionText: {
    fontFamily: typography.body,
    fontSize: 13,
    fontWeight: '600',
  },
  toggleButton: {
    borderRadius: radius.lg,
    overflow: 'hidden',
    marginBottom: spacing.lg,
  },
  toggleGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
  },
  toggleText: {
    fontFamily: typography.body,
    fontSize: 15,
    fontWeight: '600',
    color: colors.neutral[0],
  },
  featuresRow: {
    flexDirection: 'row',
    gap: spacing.md,
    marginBottom: spacing.md,
  },
  featureCard: {
    flex: 1,
    backgroundColor: colors.neutral[900],
    borderRadius: radius.lg,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.neutral[800],
  },
  featureInactive: { opacity: 0.5 },
  featureIconWrap: { marginBottom: spacing.sm },
  featureTitle: {
    fontFamily: typography.body,
    fontSize: 14,
    fontWeight: '600',
    color: colors.neutral[100],
    marginBottom: spacing.xs,
  },
  featureDesc: {
    fontFamily: typography.body,
    fontSize: 12,
    lineHeight: 17,
    color: colors.neutral[400],
  },
  featureStatus: {
    position: 'absolute',
    top: spacing.md,
    right: spacing.md,
    width: 8, height: 8,
    borderRadius: 4,
  },
  statusDotActive: { backgroundColor: colors.success[400] },
  statusDotInactive: { backgroundColor: colors.neutral[600] },
  statsRow: {
    flexDirection: 'row',
    gap: spacing.md,
    marginBottom: spacing.lg,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.neutral[900],
    borderRadius: radius.lg,
    padding: spacing.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.neutral[800],
  },
  statIconWrap: { marginBottom: spacing.xs },
  statValue: {
    fontFamily: typography.heading,
    fontSize: 28,
  },
  statLabel: {
    fontFamily: typography.body,
    fontSize: 11,
    color: colors.neutral[400],
    marginTop: spacing.xs,
    textAlign: 'center',
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  sectionTitle: {
    fontFamily: typography.body,
    fontSize: 15,
    fontWeight: '600',
    color: colors.neutral[200],
  },
  activityList: {
    backgroundColor: colors.neutral[900],
    borderRadius: radius.lg,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.neutral[800],
    gap: spacing.md,
  },
  activityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  activityDot: {
    width: 10, height: 10,
    borderRadius: 5,
  },
  activityContent: { flex: 1 },
  activityEvent: {
    fontFamily: typography.body,
    fontSize: 13,
    fontWeight: '500',
    color: colors.neutral[100],
  },
  activityFile: {
    fontFamily: typography.body,
    fontSize: 11,
    color: colors.neutral[400],
    marginTop: 2,
  },
  activityTime: {
    fontFamily: typography.body,
    fontSize: 11,
    color: colors.neutral[500],
  },
  emptyText: {
    fontFamily: typography.body,
    fontSize: 13,
    color: colors.neutral[500],
    textAlign: 'center',
    paddingVertical: spacing.md,
  },
});
